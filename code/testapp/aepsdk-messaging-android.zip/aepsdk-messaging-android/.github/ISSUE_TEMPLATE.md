---
name: Blank issue
labels: task
---
## Prerequisites
<!--- Go through the items below before logging an issue -->
- [ ] I have searched in this repository's issues to see if it has already been reported.
- [ ] This is not a Security Disclosure, otherwise please follow the guidelines in [Security Policy](https://github.com/adobe/aepsdk-messaging-android/security/policy).
