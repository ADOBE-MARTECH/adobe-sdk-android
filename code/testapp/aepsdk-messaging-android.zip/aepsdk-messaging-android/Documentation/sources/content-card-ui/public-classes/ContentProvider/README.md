# Content Providers

Messaging provides the following content providers to be used for retrieving and refreshing content cards.

- [AepUIContentProvider](./aepuicontentprovider.md)
- [ContentCardUIProvider](./contentcarduiprovider.md)
