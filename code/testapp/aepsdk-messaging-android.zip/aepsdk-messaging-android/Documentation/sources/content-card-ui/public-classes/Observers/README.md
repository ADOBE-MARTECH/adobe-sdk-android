# Event Observers

Messaging provides the following event observers to be used for observing events which occur on displayed content cards.

- [AepUIEventObserver](./aepuieventobserver.md)
- [ContentCardEventObserver](./contentcardeventobserver.md)
