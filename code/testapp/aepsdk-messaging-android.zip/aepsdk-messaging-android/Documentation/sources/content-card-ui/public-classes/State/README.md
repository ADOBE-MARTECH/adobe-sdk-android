# State

Messaging provides the following State classes that store the current state of a content card:

- [AepCardUIState](./aepcarduistate.md)
- [SmallImageCardUIState](./smallimagecarduistate.md)
- [LargeImageCardUIState](./largeimagecarduistate.md)
- [ImageOnlyCardUIState](./imageonlycarduistate.md)
