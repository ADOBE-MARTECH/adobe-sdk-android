# Styles

Messaging provides the following styles that can be used to customize the UI elements of content cards:

- [AepButtonStyle](./aepbuttonstyle.md)
- [AepCardStyle](./aepcardstyle.md)
- [AepColumnStyle](./aepcolumnstyle.md)
- [AepIconStyle](./aepiconstyle.md)
- [AepImageStyle](./aepimagestyle.md)
- [AepRowStyle](./aeprowstyle.md)
- [AepTextStyle](./aeptextstyle.md)
- [SmallImageUIStyle](./smallimageuistyle.md)
- [LargeImageUIStyle](./largeimageuistyle.md)
- [ImageOnlyUIStyle](./imageonlyuistyle.md)
