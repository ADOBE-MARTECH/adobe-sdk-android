# Data Class - AepIcon

Data class representing an icon element in the UI.

## Public Properties

| Property |	Type |	Description |
| --- | --- | --- |
| drawableId | Int |	The drawable resource ID for the icon. |
