# Data Class - AepImage

Data class representing an image element in the UI.

## Public Properties

| Property | Type | Description |
| --- | --- | --- |
| url | String? | The URL of the image. |
| darkUrl | String? | The URL of the image for dark mode. |
