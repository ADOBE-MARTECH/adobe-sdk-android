# Data Class - AepText

Data class representing a text element in the UI.

## Public Properties

| Property | Type | Description |
| --- | --- | --- |
| content | String | The content of the text. |
