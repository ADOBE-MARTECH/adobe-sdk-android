# Interface - AepUITemplate

Interface representing a generic UI template in AEP.

## Methods

### getType 

Gets the type of the UI template.

#### Syntax

``` kotlin
fun getType(): AepUITemplateType
```